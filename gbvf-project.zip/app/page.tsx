'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { Shield, MessageCircle, FileText, Send, Loader2 } from 'lucide-react'
import { generateText } from 'ai'
import { openai } from '@ai-sdk/openai'

export default function AIAnonymousReporting() {
  const [step, setStep] = useState(1)
  const [reportData, setReportData] = useState({
    incidentType: '',
    description: '',
    location: '',
    timeframe: '',
    urgency: '',
    needsSupport: false,
    aiSuggestions: ''
  })
  const [isGenerating, setIsGenerating] = useState(false)
  const [aiResponse, setAiResponse] = useState('')

  const handleAIAssistance = async () => {
    setIsGenerating(true)
    try {
      const prompt = `You are a compassionate AI assistant helping someone report a gender-based violence incident anonymously. Based on this information:
      
      Incident Type: ${reportData.incidentType}
      Description: ${reportData.description}
      Location: ${reportData.location}
      Timeframe: ${reportData.timeframe}
      
      Please provide:
      1. Gentle guidance on what additional details might be helpful (without being intrusive)
      2. Reassurance about their safety and the reporting process
      3. Suggestions for immediate safety measures if needed
      4. Information about available support resources
      
      Keep your response supportive, non-judgmental, and focused on their wellbeing. Limit to 200 words.`

      const { text } = await generateText({
        model: openai('gpt-4o'),
        prompt: prompt,
        system: 'You are a trauma-informed AI assistant specializing in supporting survivors of gender-based violence. Always prioritize safety, confidentiality, and empowerment.'
      })

      setAiResponse(text)
      setReportData(prev => ({ ...prev, aiSuggestions: text }))
    } catch (error) {
      console.error('Error generating AI response:', error)
      setAiResponse('I apologize, but I cannot provide assistance at this moment. Please continue with your report, and remember that support is available through our other resources.')
    } finally {
      setIsGenerating(false)
    }
  }

  const handleSubmit = async () => {
    // In a real implementation, this would send to your PHP backend
    console.log('Submitting anonymous report:', reportData)
    alert('Your anonymous report has been submitted securely. Thank you for your courage in speaking up.')
    
    // Reset form
    setStep(1)
    setReportData({
      incidentType: '',
      description: '',
      location: '',
      timeframe: '',
      urgency: '',
      needsSupport: false,
      aiSuggestions: ''
    })
    setAiResponse('')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Shield className="h-12 w-12 text-purple-600 mr-3" />
            <h1 className="text-3xl font-bold text-gray-800">AI Anonymous Reporting</h1>
          </div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Report incidents safely and anonymously with AI-powered guidance. Your privacy and safety are our top priorities.
          </p>
        </div>

        {/* Progress Indicator */}
        <div className="flex justify-center mb-8">
          <div className="flex items-center space-x-4">
            {[1, 2, 3].map((num) => (
              <div key={num} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  step >= num ? 'bg-purple-600 text-white' : 'bg-gray-200 text-gray-600'
                }`}>
                  {num}
                </div>
                {num < 3 && <div className={`w-12 h-1 ${step > num ? 'bg-purple-600' : 'bg-gray-200'}`} />}
              </div>
            ))}
          </div>
        </div>

        {/* Step 1: Basic Information */}
        {step === 1 && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="h-5 w-5 mr-2" />
                Basic Information
              </CardTitle>
              <CardDescription>
                Please provide basic details about the incident. All information is kept completely anonymous.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Type of Incident</label>
                <Select value={reportData.incidentType} onValueChange={(value) => 
                  setReportData(prev => ({ ...prev, incidentType: value }))
                }>
                  <SelectTrigger>
                    <SelectValue placeholder="Select incident type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="physical-violence">Physical Violence</SelectItem>
                    <SelectItem value="emotional-abuse">Emotional/Psychological Abuse</SelectItem>
                    <SelectItem value="sexual-violence">Sexual Violence</SelectItem>
                    <SelectItem value="financial-abuse">Financial Abuse</SelectItem>
                    <SelectItem value="stalking">Stalking/Harassment</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Urgency Level</label>
                <Select value={reportData.urgency} onValueChange={(value) => 
                  setReportData(prev => ({ ...prev, urgency: value }))
                }>
                  <SelectTrigger>
                    <SelectValue placeholder="Select urgency level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="immediate">Immediate danger - need help now</SelectItem>
                    <SelectItem value="urgent">Urgent - within 24 hours</SelectItem>
                    <SelectItem value="important">Important - within a week</SelectItem>
                    <SelectItem value="general">General reporting</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">When did this occur?</label>
                <Select value={reportData.timeframe} onValueChange={(value) => 
                  setReportData(prev => ({ ...prev, timeframe: value }))
                }>
                  <SelectTrigger>
                    <SelectValue placeholder="Select timeframe" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="today">Today</SelectItem>
                    <SelectItem value="yesterday">Yesterday</SelectItem>
                    <SelectItem value="this-week">This week</SelectItem>
                    <SelectItem value="this-month">This month</SelectItem>
                    <SelectItem value="longer">Longer ago</SelectItem>
                    <SelectItem value="ongoing">Ongoing situation</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button 
                onClick={() => setStep(2)} 
                className="w-full bg-purple-600 hover:bg-purple-700"
                disabled={!reportData.incidentType || !reportData.urgency || !reportData.timeframe}
              >
                Continue to Details
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Detailed Description */}
        {step === 2 && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center">
                <MessageCircle className="h-5 w-5 mr-2" />
                Incident Details
              </CardTitle>
              <CardDescription>
                Describe what happened in your own words. Include as much or as little detail as you're comfortable sharing.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Description of Incident</label>
                <Textarea
                  value={reportData.description}
                  onChange={(e) => setReportData(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Please describe what happened. Take your time and share what feels safe for you to share."
                  className="min-h-32"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Location (General Area Only)</label>
                <Textarea
                  value={reportData.location}
                  onChange={(e) => setReportData(prev => ({ ...prev, location: e.target.value }))}
                  placeholder="General area where incident occurred (e.g., 'workplace', 'home', 'public transport', 'university campus'). Do not include specific addresses."
                  className="min-h-20"
                />
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="support"
                  checked={reportData.needsSupport}
                  onCheckedChange={(checked) => 
                    setReportData(prev => ({ ...prev, needsSupport: checked as boolean }))
                  }
                />
                <label htmlFor="support" className="text-sm">
                  I would like information about support services
                </label>
              </div>

              <div className="flex space-x-3">
                <Button 
                  onClick={() => setStep(1)} 
                  variant="outline"
                  className="flex-1"
                >
                  Back
                </Button>
                <Button 
                  onClick={handleAIAssistance}
                  variant="outline"
                  className="flex-1"
                  disabled={isGenerating || !reportData.description}
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Getting AI Guidance...
                    </>
                  ) : (
                    'Get AI Guidance'
                  )}
                </Button>
                <Button 
                  onClick={() => setStep(3)} 
                  className="flex-1 bg-purple-600 hover:bg-purple-700"
                  disabled={!reportData.description}
                >
                  Continue
                </Button>
              </div>

              {aiResponse && (
                <Card className="mt-4 border-purple-200 bg-purple-50">
                  <CardHeader>
                    <CardTitle className="text-lg text-purple-800">AI Guidance</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-purple-700 whitespace-pre-wrap">{aiResponse}</p>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        )}

        {/* Step 3: Review and Submit */}
        {step === 3 && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Send className="h-5 w-5 mr-2" />
                Review and Submit
              </CardTitle>
              <CardDescription>
                Please review your report before submitting. Your information will be kept completely anonymous.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg space-y-3">
                <div>
                  <strong>Incident Type:</strong> {reportData.incidentType.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </div>
                <div>
                  <strong>Urgency:</strong> {reportData.urgency.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </div>
                <div>
                  <strong>Timeframe:</strong> {reportData.timeframe.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </div>
                <div>
                  <strong>Location:</strong> {reportData.location}
                </div>
                <div>
                  <strong>Description:</strong> {reportData.description}
                </div>
                <div>
                  <strong>Support Requested:</strong> {reportData.needsSupport ? 'Yes' : 'No'}
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h4 className="font-medium text-blue-800 mb-2">Privacy Notice</h4>
                <p className="text-blue-700 text-sm">
                  Your report is completely anonymous. No personal identifying information is collected or stored. 
                  This report will be used to improve safety measures and provide better support services.
                </p>
              </div>

              <div className="flex space-x-3">
                <Button 
                  onClick={() => setStep(2)} 
                  variant="outline"
                  className="flex-1"
                >
                  Back to Edit
                </Button>
                <Button 
                  onClick={handleSubmit}
                  className="flex-1 bg-purple-600 hover:bg-purple-700"
                >
                  Submit Anonymous Report
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Emergency Notice */}
        <Card className="border-red-200 bg-red-50">
          <CardContent className="pt-6">
            <div className="flex items-start space-x-3">
              <Shield className="h-6 w-6 text-red-600 mt-1" />
              <div>
                <h4 className="font-medium text-red-800 mb-2">Emergency Contacts</h4>
                <p className="text-red-700 text-sm mb-2">
                  If you are in immediate danger, please contact emergency services:
                </p>
                <ul className="text-red-700 text-sm space-y-1">
                  <li>• SAPS Emergency: 10111</li>
                  <li>• GBV Command Centre: 0800 428 428</li>
                  <li>• USSD: *120*7867#</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
