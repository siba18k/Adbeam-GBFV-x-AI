<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Enable error reporting for debugging (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Function to sanitize input data
function sanitizeInput($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Function to generate anonymous report ID
function generateReportId() {
    return 'ANON_' . date('Ymd') . '_' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 8));
}

// Function to log errors
function logError($message) {
    $logFile = 'logs/anonymous_reports_errors.log';
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[$timestamp] $message" . PHP_EOL;
    
    // Create logs directory if it doesn't exist
    if (!file_exists('logs')) {
        mkdir('logs', 0755, true);
    }
    
    file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);
}

try {
    // Check if request method is POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Only POST requests are allowed');
    }
    
    // Get JSON input
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON data received');
    }
    
    // Validate required fields
    $requiredFields = ['incidentType', 'urgency', 'timeframe', 'description'];
    foreach ($requiredFields as $field) {
        if (empty($data[$field])) {
            throw new Exception("Missing required field: $field");
        }
    }
    
    // Sanitize all input data
    $reportData = [
        'reportId' => generateReportId(),
        'incidentType' => sanitizeInput($data['incidentType']),
        'urgency' => sanitizeInput($data['urgency']),
        'timeframe' => sanitizeInput($data['timeframe']),
        'location' => sanitizeInput($data['location'] ?? ''),
        'description' => sanitizeInput($data['description']),
        'needsSupport' => isset($data['needsSupport']) ? (bool)$data['needsSupport'] : false,
        'submissionTime' => date('Y-m-d H:i:s'),
        'ipHash' => hash('sha256', $_SERVER['REMOTE_ADDR'] ?? 'unknown'), // Hash IP for basic analytics without storing actual IP
    ];
    
    // Validate incident type
    $validIncidentTypes = ['physical-violence', 'emotional-abuse', 'sexual-violence', 'financial-abuse', 'stalking', 'other'];
    if (!in_array($reportData['incidentType'], $validIncidentTypes)) {
        throw new Exception('Invalid incident type');
    }
    
    // Validate urgency level
    $validUrgencyLevels = ['immediate', 'urgent', 'important', 'general'];
    if (!in_array($reportData['urgency'], $validUrgencyLevels)) {
        throw new Exception('Invalid urgency level');
    }
    
    // Create anonymous reports directory if it doesn't exist
    $reportsDir = 'anonymous_reports';
    if (!file_exists($reportsDir)) {
        mkdir($reportsDir, 0755, true);
    }
    
    // Save report to file (using JSON format for easy parsing)
    $filename = $reportsDir . '/report_' . $reportData['reportId'] . '.json';
    $jsonData = json_encode($reportData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    
    if (file_put_contents($filename, $jsonData, LOCK_EX) === false) {
        throw new Exception('Failed to save report');
    }
    
    // Log successful submission (without sensitive data)
    $logMessage = "Anonymous report submitted successfully. ID: {$reportData['reportId']}, Type: {$reportData['incidentType']}, Urgency: {$reportData['urgency']}";
    logError($logMessage);
    
    // Check if immediate help is needed
    $immediateResponse = [];
    if ($reportData['urgency'] === 'immediate') {
        $immediateResponse = [
            'immediateHelp' => true,
            'emergencyContacts' => [
                'SAPS Emergency' => '10111',
                'GBV Command Centre' => '0800 428 428',
                'USSD' => '*120*7867#'
            ],
            'message' => 'Based on your urgency level, please consider contacting emergency services immediately.'
        ];
    }
    
    // Prepare support resources based on needs
    $supportResources = [];
    if ($reportData['needsSupport']) {
        $supportResources = [
            'counseling' => 'Professional counseling services are available',
            'legal' => 'Legal aid and information about your rights',
            'shelter' => 'Safe accommodation options if needed',
            'support_groups' => 'Connect with support groups and peer support'
        ];
    }
    
    // Send success response
    $response = [
        'success' => true,
        'message' => 'Report submitted successfully',
        'reportId' => $reportData['reportId'],
        'timestamp' => $reportData['submissionTime']
    ];
    
    // Add immediate help info if needed
    if (!empty($immediateResponse)) {
        $response['immediateHelp'] = $immediateResponse;
    }
    
    // Add support resources if requested
    if (!empty($supportResources)) {
        $response['supportResources'] = $supportResources;
    }
    
    echo json_encode($response);
    
} catch (Exception $e) {
    // Log the error
    logError("Error processing anonymous report: " . $e->getMessage());
    
    // Send error response
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Unable to process your report at this time. Please try again later.',
        'error' => $e->getMessage() // Remove this in production
    ]);
}

// Additional security measures
function addSecurityHeaders() {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
}

addSecurityHeaders();
?>
