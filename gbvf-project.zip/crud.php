<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['id'])) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['id'];

// Database configuration
$config = require 'C:/xampp/secure_config/config.php';
$host = $config['host'];
$db_name = $config['db'];
$user = $config['user'];
$pass = $config['pass'];

// Create connection
$conn = new mysqli($host, $user, $pass, $db_name);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle account deletion
    if (isset($_POST['delete_account'])) {
        // Start transaction to ensure data integrity
        $conn->begin_transaction();
        try {
            // Delete emergency contacts
            $stmt = $conn->prepare("DELETE FROM emergency_contacts WHERE user_id = ?");
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $stmt->close();

            // Delete the user
            $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $stmt->close();

            // Commit the transaction
            $conn->commit();

            // Destroy the session and redirect to logout page (or a deleted account page)
            session_destroy();
            header('Location: logout.php?deleted=1'); // You'll need to create a logout.php
            exit;
        } catch (mysqli_sql_exception $exception) {
            $conn->rollback();
            throw $exception; // Or handle the error appropriately
        }
    } else {
        // Update user details
        $stmt = $conn->prepare("UPDATE users SET
            name = ?, surname = ?, username = ?, email = ?,
            phone = ?, address = ? WHERE id = ?");

        $stmt->bind_param("ssssssi",
            $_POST['name'], $_POST['surname'], $_POST['username'],
            $_POST['email'], $_POST['phone'], $_POST['address'], $userId);
        $stmt->execute();
        $stmt->close();

        // Update password if provided
        if (!empty($_POST['password']) && $_POST['password'] === $_POST['confirm_password']) {
            $hashed_password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $hashed_password, $userId);
            $stmt->execute();
            $stmt->close();
        }

        // Update emergency contacts
        $conn->query("DELETE FROM emergency_contacts WHERE user_id = $userId");

        if (isset($_POST['contact_name'])) {
            $stmt = $conn->prepare("INSERT INTO emergency_contacts
                (user_id, contact_name, relationship, contact_phone)
                VALUES (?, ?, ?, ?)");

            for ($i = 0; $i < count($_POST['contact_name']); $i++) {
                if (!empty($_POST['contact_name'][$i])) {
                    $stmt->bind_param("isss", $userId,
                        $_POST['contact_name'][$i],
                        $_POST['relationship'][$i],
                        $_POST['contact_phone'][$i]);
                    $stmt->execute();
                }
            }
            $stmt->close();
        }

        // Refresh the page to show updated data
        header("Location: crud.php");
        exit;
    }
}

// Fetch user data
$user = $conn->query("SELECT * FROM users WHERE id = $userId")->fetch_assoc();

// Fetch emergency contacts
$contacts = $conn->query("SELECT * FROM emergency_contacts WHERE user_id = $userId");

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
    .form-group {
            margin-bottom: 1.5rem;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, rgb(75, 22, 76), rgb(248, 231, 246));
            display: flex;
            justify-content: center;
            align-items: center;
            overflow-y: auto; 
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        .form-container { 
            background-color: rgb(245, 245, 245);
            border-color: rgb(75, 22, 76);
            box-shadow: 0 8px 16px rgba(75, 22, 76, 0.2);
            transition: all 0.3s ease;
            position: relative;
            z-index: 5;
            padding: 10px; 
            max-width: 95vw; 
            width: 50%;
        }
        .form-container:hover {
            transform: translateY(-6px);
            box-shadow: 0 12px 24px rgba(75, 22, 76, 0.4);
            background-color: rgb(248, 231, 246);
        }
        
        .mt-8.border-t.pt-6 {
            margin-top: 1.5rem; 
            padding-top: 1rem; 
            border-top: 1px solid #e5e7eb;
        }
        .contact-container {
            background: #f8fafc;
            padding: 0.75rem; 
            border-radius: 0.5rem;
            margin-bottom: 0.75rem; 
            border: 1px solid #edf2f7; 
        }
        .remove-contact {
            margin-top: 0.25rem; 
            padding: 0.25rem 0.5rem; 
            font-size: 0.8rem; 
        }
        button[name="delete_account"] {
            background-color: #dc2626; 
            color: white;
            border: none;
            padding: 0.6rem 0.8rem; 
            border-radius: 0.5rem;
            cursor: pointer;
            font-size: 0.8rem; 
            line-height: 1.2;
            transition: background-color 0.2s ease-in-out;
        }
        button[name="delete_account"]:hover {
            background-color: #b91c1c;
        }
        h1 {
            font-size: 1.75rem; 
            margin-bottom: 1.5rem;
            color: #374151;
        }
        h2 {
            font-size: 1.25rem; 
            margin-bottom: 1rem;
            color: #4b5563;
        }
        .grid {
            grid-gap: 0.75rem; 
        }
        .form-group label {
            font-size: 0.875rem;
            margin-bottom: 0.5rem;
            color: #6b7280;
        }
        .form-group input {
            padding: 0.6rem 0.75rem; 
            font-size: 0.875rem;
        }
        .flex.justify-between.items-center {
            margin-top: 1.5rem;
        }
        .flex.justify-between button,
        .flex.justify-between a {
            padding: 0.6rem 1rem; 
            font-size: 0.875rem;
        }
        #add-contact {
            margin-top: 1rem;
            padding: 0.6rem 1rem;
            font-size: 0.875rem;
        }
    </style>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto py-8 max-w-4xl">
        <div class="bg-white rounded-lg shadow-md p-8">
            <h1 class="text-2xl font-bold mb-6">Edit Your Profile</h1>

            <form method="POST">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="form-group">
                        <label class="block text-gray-700 mb-2">First Name</label>
                        <input type="text" name="name" value="<?= htmlspecialchars($user['name'] ?? '') ?>"
                            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>

                    <div class="form-group">
                        <label class="block text-gray-700 mb-2">Last Name</label>
                        <input type="text" name="surname" value="<?= htmlspecialchars($user['surname'] ?? '') ?>"
                            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>

                    <div class="form-group">
                        <label class="block text-gray-700 mb-2">Username</label>
                        <input type="text" name="username" value="<?= htmlspecialchars($user['username'] ?? '') ?>"
                            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>

                    <div class="form-group">
                        <label class="block text-gray-700 mb-2">Email</label>
                        <input type="email" name="email" value="<?= htmlspecialchars($user['email'] ?? '') ?>"
                            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>

                    <div class="form-group">
                        <label class="block text-gray-700 mb-2">Phone</label>
                        <input type="text" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>"
                            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>

                    <div class="form-group">
                        <label class="block text-gray-700 mb-2">Address</label>
                        <input type="text" name="address" value="<?= htmlspecialchars($user['address'] ?? '') ?>"
                            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                </div>

                <div class="mt-8 border-t pt-6">
                    <h2 class="text-xl font-semibold mb-4">Change Password</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="form-group">
                            <label class="block text-gray-700 mb-2">New Password</label>
                            <input type="password" name="password"
                                class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>

                        <div class="form-group">
                            <label class="block text-gray-700 mb-2">Confirm Password</label>
                            <input type="password" name="confirm_password"
                                class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                    </div>
                </div>

                <div class="mt-8 border-t pt-6">
                    <h2 class="text-xl font-semibold mb-4">Emergency Contacts (Max 3)</h2>
                    <div id="contacts-container">
                        <?php if ($contacts->num_rows > 0): ?>
                            <?php while ($contact = $contacts->fetch_assoc()): ?>
                                <div class="contact-container">
                                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                        <div class="form-group">
                                            <label class="block text-gray-700 mb-2">Contact Name</label>
                                            <input type="text" name="contact_name[]"
                                                value="<?= htmlspecialchars($contact['contact_name']) ?>"
                                                class="w-full px-4 py-2 border rounded-lg">
                                        </div>
                                        <div class="form-group">
                                            <label class="block text-gray-700 mb-2">Relationship</label>
                                            <input type="text" name="relationship[]"
                                                value="<?= htmlspecialchars($contact['relationship']) ?>"
                                                class="w-full px-4 py-2 border rounded-lg">
                                        </div>
                                        <div class="form-group">
                                            <label class="block text-gray-700 mb-2">Phone</label>
                                            <input type="text" name="contact_phone[]"
                                                value="<?= htmlspecialchars($contact['contact_phone']) ?>"
                                                class="w-full px-4 py-2 border rounded-lg">
                                        </div>
                                    </div>
                                    <button type="button" class="remove-contact mt-2 px-3 py-1 bg-red-500 text-white rounded text-sm">
                                        Remove
                                    </button>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="contact-container">
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div class="form-group">
                                        <label class="block text-gray-700 mb-2">Contact Name</label>
                                        <input type="text" name="contact_name[]" class="w-full px-4 py-2 border rounded-lg">
                                    </div>
                                    <div class="form-group">
                                        <label class="block text-gray-700 mb-2">Relationship</label>
                                        <input type="text" name="relationship[]" class="w-full px-4 py-2 border rounded-lg">
                                    </div>
                                    <div class="form-group">
                                        <label class="block text-gray-700 mb-2">Phone</label>
                                        <input type="text" name="contact_phone[]" class="w-full px-4 py-2 border rounded-lg">
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <button type="button" id="add-contact" class="mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600">
                        <i class="fas fa-plus mr-2"></i>Add Another Contact
                    </button>
                </div>

                <div class="mt-8 flex justify-between items-center">
                    <div>
                        <button type="submit" class="px-6 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600">
                            Save Changes
                        </button>
                        <a href="home.php" class="ml-4 px-6 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600">
                            Cancel
                        </a>
                    </div>
                    <button type="submit" name="delete_account" class="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-400">
                        Delete Account
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const contactsContainer = document.getElementById('contacts-container');
            const addContactBtn = document.getElementById('add-contact');

            addContactBtn.addEventListener('click', function() {
                const contactCount = document.querySelectorAll('.contact-container').length;
                if (contactCount >= 3) {
                    alert('Maximum of 3 emergency contacts allowed');
                    return;
                }

                const newContact = document.createElement('div');
                newContact.className = 'contact-container mt-4';
                newContact.innerHTML = `
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div class="form-group">
                            <label class="block text-gray-700 mb-2">Contact Name</label>
                            <input type="text" name="contact_name[]" class="w-full px-4 py-2 border rounded-lg">
                        </div>
                        <div class="form-group">
                            <label class="block text-gray-700 mb-2">Relationship</label>
                            <input type="text" name="relationship[]" class="w-full px-4 py-2 border rounded-lg">
                        </div>
                        <div class="form-group">
                            <label class="block text-gray-700 mb-2">Phone</label>
                            <input type="text" name="contact_phone[]" class="w-full px-4 py-2 border rounded-lg">
                        </div>
                    </div>
                    <button type="button" class="remove-contact mt-2 px-3 py-1 bg-red-500 text-white rounded text-sm">
                        Remove
                    </button>
                `;

                contactsContainer.appendChild(newContact);

                // Add event listener to new remove button
                newContact.querySelector('.remove-contact').addEventListener('click', function() {
                    contactsContainer.removeChild(newContact);
                });
            });

            // Add event listeners to existing remove buttons
            document.querySelectorAll('.remove-contact').forEach(btn => {
                btn.addEventListener('click', function() {
                    contactsContainer.removeChild(btn.closest('.contact-container'));
                });
            });
        });
    </script>
</body>
</html>
