<?php
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        echo json_encode(['success' => false, 'message' => 'Invalid JSON received.']);
        exit;
    }

    if (empty($data['story'])) {
        echo json_encode(['success' => false, 'message' => 'Story content cannot be empty.']);
        exit;
    }
    if (empty($data['consentGiven'])) {
        echo json_encode(['success' => false, 'message' => 'Consent must be given.']);
        exit;
    }

    $name = isset($data['name']) ? trim($data['name']) : 'Anonymous';
    $email = isset($data['email']) ? trim($data['email']) : '';
    $ageRange = isset($data['ageRange']) ? trim($data['ageRange']) : 'Not specified';
    $title = isset($data['title']) ? trim($data['title']) : 'No Title';
    $story = trim($data['story']);
    $messageOfHope = isset($data['messageOfHope']) ? trim($data['messageOfHope']) : 'None';
    $isAnonymous = isset($data['isAnonymous']) ? ($data['isAnonymous'] ? 'Yes' : 'No') : 'No';

    if ($isAnonymous === 'Yes') {
        $name = 'Anonymous';
        $email = '';
    }

    $timestamp = date('Y-m-d H:i:s');
    $filename = 'story_' . date('Ymd_His') . '_' . uniqid() . '.txt';
    $folderPath = 'Stories/';

    if (!is_dir($folderPath)) {
        mkdir($folderPath, 0755, true);
    }

    $filePath = $folderPath . $filename;

    $storyContent = "Timestamp: " . $timestamp . "\n" .
                    "Name: " . $name . "\n" .
                    "Email: " . ($email ? $email : 'N/A') . "\n" .
                    "Age Range: " . $ageRange . "\n" .
                    "Title: " . $title . "\n" .
                    "Is Anonymous: " . $isAnonymous . "\n" .
                    "Consent Given: " . ($data['consentGiven'] ? 'Yes' : 'No') . "\n\n" .
                    "--- Story ---\n" . $story . "\n\n" .
                    "--- Message of Hope ---\n" . ($messageOfHope ? $messageOfHope : 'N/A') . "\n";

    if (file_put_contents($filePath, $storyContent)) {
        echo json_encode(['success' => true, 'message' => 'Story submitted successfully!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to save story. Check folder permissions.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}
?>
