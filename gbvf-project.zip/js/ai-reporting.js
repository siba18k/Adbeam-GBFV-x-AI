// AI Anonymous Reporting JavaScript
let currentStep = 1;
const totalSteps = 3;
let reportData = {
    incidentType: '',
    urgency: '',
    timeframe: '',
    description: '',
    location: '',
    needsSupport: false,
    aiSuggestions: ''
};

// Translation object for original texts
let translations = {};

document.addEventListener('DOMContentLoaded', function() {
    // Load original texts for translation
    loadOriginalTexts();
    
    // Initialize form validation
    initializeFormValidation();
    
    // Add event listeners
    addEventListeners();
    
    // Initialize the form when page loads
    updateStepDisplay();
    
    // Add event listeners for form validation
    const requiredFields = document.querySelectorAll('select[required]');
    requiredFields.forEach(field => {
        field.addEventListener('change', validateCurrentStep);
    });
    
    // Add emergency contact click handlers
    const emergencyLinks = document.querySelectorAll('.emergency-text ul li');
    emergencyLinks.forEach(link => {
        link.style.cursor = 'pointer';
        link.addEventListener('click', function() {
            const text = this.textContent;
            const number = text.match(/[\d\s\*#]+/)[0].replace(/\s/g, '');
            callEmergency(number);
        });
    });
});

function loadOriginalTexts() {
    if (window.originalTextsLoaded) return;
    
    document.querySelectorAll('[data-translate]').forEach(element => {
        const key = element.getAttribute('data-translate');
        if (element.innerText !== undefined && element.innerText.trim() !== '') {
            translations[key] = element.innerText;
        } else if (element.hasAttribute('placeholder')) {
            translations[key] = element.getAttribute('placeholder');
        } else if (element.hasAttribute('title')) {
            translations[key] = element.getAttribute('title');
        }
    });
    
    window.originalTextsLoaded = true;
}

function addEventListeners() {
    // Form field change listeners
    document.getElementById('incidentType').addEventListener('change', updateReportData);
    document.getElementById('urgency').addEventListener('change', updateReportData);
    document.getElementById('timeframe').addEventListener('change', updateReportData);
    document.getElementById('description').addEventListener('input', updateReportData);
    document.getElementById('location').addEventListener('input', updateReportData);
    document.getElementById('needsSupport').addEventListener('change', updateReportData);
}

function updateReportData() {
    reportData.incidentType = document.getElementById('incidentType').value;
    reportData.urgency = document.getElementById('urgency').value;
    reportData.timeframe = document.getElementById('timeframe').value;
    reportData.description = document.getElementById('description').value;
    reportData.location = document.getElementById('location').value;
    reportData.needsSupport = document.getElementById('needsSupport').checked;
}

function initializeFormValidation() {
    // Add real-time validation feedback
    const requiredFields = ['incidentType', 'urgency', 'timeframe'];
    
    requiredFields.forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (field) {
            field.addEventListener('change', function() {
                validateField(this);
            });
        }
    });
    
    // Validate description field
    const descriptionField = document.getElementById('description');
    if (descriptionField) {
        descriptionField.addEventListener('input', function() {
            validateField(this);
        });
    }
}

function validateField(field) {
    const isValid = field.value.trim() !== '';
    
    if (isValid) {
        field.style.borderColor = '#10b981';
        field.style.boxShadow = '0 0 0 3px rgba(16, 185, 129, 0.1)';
    } else {
        field.style.borderColor = '#ef4444';
        field.style.boxShadow = '0 0 0 3px rgba(239, 68, 68, 0.1)';
    }
    
    return isValid;
}

function nextStep() {
    if (validateCurrentStep()) {
        if (currentStep < totalSteps) {
            currentStep++;
            updateStepDisplay();
            
            if (currentStep === 3) {
                populateReview();
            }
        }
    }
}

function previousStep() {
    if (currentStep > 1) {
        currentStep--;
        updateStepDisplay();
    }
}

function updateStepDisplay() {
    // Update step indicators
    document.querySelectorAll('.step').forEach((step, index) => {
        const stepNumber = index + 1;
        if (stepNumber <= currentStep) {
            step.classList.add('active');
        } else {
            step.classList.remove('active');
        }
    });
    
    // Update step content visibility
    document.querySelectorAll('.step-content').forEach((content, index) => {
        const stepNumber = index + 1;
        if (stepNumber === currentStep) {
            content.classList.add('active');
        } else {
            content.classList.remove('active');
        }
    });
    
    // Scroll to top of form
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function validateCurrentStep() {
    let isValid = true;
    const currentStepElement = document.getElementById(`step${currentStep}`);
    const requiredFields = currentStepElement.querySelectorAll('select[required], textarea[required]');
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.style.borderColor = '#dc3545';
            isValid = false;
            
            // Show error message
            showError(`Please complete all required fields before continuing.`);
        } else {
            field.style.borderColor = '#E0E0E0';
        }
    });
    
    return isValid;
}

function showError(message) {
    // Remove existing error messages
    const existingError = document.querySelector('.error-message');
    if (existingError) {
        existingError.remove();
    }
    
    // Create new error message
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.style.cssText = `
        background: #f8d7da;
        color: #721c24;
        padding: 12px 20px;
        border-radius: 8px;
        margin: 15px 0;
        border: 1px solid #f5c6cb;
        text-align: center;
        font-weight: 500;
    `;
    errorDiv.textContent = message;
    
    // Insert error message at the top of current step
    const currentStepElement = document.getElementById(`step${currentStep}`);
    const cardContent = currentStepElement.querySelector('.card-content');
    cardContent.insertBefore(errorDiv, cardContent.firstChild);
    
    // Remove error message after 5 seconds
    setTimeout(() => {
        if (errorDiv.parentNode) {
            errorDiv.remove();
        }
    }, 5000);
}

function showSuccess(message) {
    const successDiv = document.createElement('div');
    successDiv.className = 'success-message';
    successDiv.style.cssText = `
        background: #d4edda;
        color: #155724;
        padding: 12px 20px;
        border-radius: 8px;
        margin: 15px 0;
        border: 1px solid #c3e6cb;
        text-align: center;
        font-weight: 500;
    `;
    successDiv.textContent = message;
    
    const currentStepElement = document.getElementById(`step${currentStep}`);
    const cardContent = currentStepElement.querySelector('.card-content');
    cardContent.insertBefore(successDiv, cardContent.firstChild);
    
    setTimeout(() => {
        if (successDiv.parentNode) {
            successDiv.remove();
        }
    }, 5000);
}

// AI Guidance function
async function getAIGuidance() {
    const aiBtn = document.getElementById('aiGuidanceBtn');
    const loadingOverlay = document.getElementById('loadingOverlay');
    const aiResponseArea = document.getElementById('aiResponseArea');
    const aiResponseContent = document.getElementById('aiResponseContent');
    
    // Get current form data
    const incidentType = document.getElementById('incidentType').value;
    const urgency = document.getElementById('urgency').value;
    const description = document.getElementById('description').value;
    
    if (!incidentType || !description.trim()) {
        showError('Please select an incident type and provide a description before requesting AI guidance.');
        return;
    }
    
    // Show loading
    aiBtn.disabled = true;
    aiBtn.innerHTML = '<span class="ai-icon">🤖</span> Getting guidance...';
    loadingOverlay.style.display = 'flex';
    
    try {
        // Simulate AI response (replace with actual AI API call)
        const aiResponse = await simulateAIResponse(incidentType, urgency, description);
        
        // Display AI response
        aiResponseContent.innerHTML = aiResponse;
        aiResponseArea.style.display = 'block';
        
        // Scroll to AI response
        aiResponseArea.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        
        showSuccess('AI guidance has been provided below. Please review the suggestions.');
        
    } catch (error) {
        console.error('AI Guidance Error:', error);
        showError('Unable to get AI guidance at this time. Please continue with your report or try again later.');
    } finally {
        // Hide loading
        loadingOverlay.style.display = 'none';
        aiBtn.disabled = false;
        aiBtn.innerHTML = '<span class="ai-icon">🤖</span> Get AI Guidance';
    }
}

// Simulate AI response (replace with actual AI API integration)
async function simulateAIResponse(incidentType, urgency, description) {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    let response = `<div style="line-height: 1.6;">`;
    
    // Trauma-informed opening
    response += `<p style="margin-bottom: 15px;"><strong>Thank you for sharing your experience.</strong> It takes courage to report what happened, and your safety is the most important thing.</p>`;
    
    // Incident-specific guidance
    switch (incidentType) {
        case 'physical-violence':
            response += `<h4 style="color: #4B164C; margin: 15px 0 10px 0;">Additional Information That Might Help:</h4>
            <ul style="margin-left: 20px; margin-bottom: 15px;">
                <li>Any injuries sustained (without graphic details)</li>
                <li>Whether medical attention was sought</li>
                <li>If there were any witnesses</li>
                <li>Whether this has happened before</li>
            </ul>`;
            break;
            
        case 'emotional-abuse':
            response += `<h4 style="color: #4B164C; margin: 15px 0 10px 0;">Additional Context That Might Help:</h4>
            <ul style="margin-left: 20px; margin-bottom: 15px;">
                <li>Patterns of behavior (frequency, escalation)</li>
                <li>Impact on your daily life or mental health</li>
                <li>Any threats made</li>
                <li>Whether others have witnessed this behavior</li>
            </ul>`;
            break;
            
        case 'sexual-violence':
            response += `<h4 style="color: #4B164C; margin: 15px 0 10px 0;">Important Considerations:</h4>
            <ul style="margin-left: 20px; margin-bottom: 15px;">
                <li>Only share what feels safe and comfortable for you</li>
                <li>Consider whether medical attention was or is needed</li>
                <li>Whether evidence was preserved (if applicable)</li>
                <li>Your emotional state and support needs</li>
            </ul>`;
            break;
            
        case 'financial-abuse':
            response += `<h4 style="color: #4B164C; margin: 15px 0 10px 0;">Financial Abuse Details That Help:</h4>
            <ul style="margin-left: 20px; margin-bottom: 15px;">
                <li>Types of financial control (access to money, employment interference)</li>
                <li>Impact on your ability to meet basic needs</li>
                <li>Whether you have access to any financial resources</li>
                <li>Documentation of financial abuse (if safe to obtain)</li>
            </ul>`;
            break;
            
        default:
            response += `<h4 style="color: #4B164C; margin: 15px 0 10px 0;">General Guidance:</h4>
            <ul style="margin-left: 20px; margin-bottom: 15px;">
                <li>Include any relevant context about the situation</li>
                <li>Mention if this is part of a pattern</li>
                <li>Note any immediate safety concerns</li>
                <li>Describe the impact this has had on you</li>
            </ul>`;
    }
    
    // Urgency-specific advice
    if (urgency === 'immediate') {
        response += `<div style="background: #fff3cd; border: 1px solid #ffc107; border-radius: 8px; padding: 15px; margin: 15px 0;">
            <h4 style="color: #856404; margin-bottom: 10px;">⚠️ Immediate Safety</h4>
            <p style="color: #856404; margin: 0;">Since you indicated immediate danger, please consider contacting emergency services right away:</p>
            <ul style="color: #856404; margin: 10px 0 0 20px;">
                <li>SAPS Emergency: 10111</li>
                <li>GBV Command Centre: 0800 428 428</li>
            </ul>
        </div>`;
    }
    
    // Support resources
    response += `<h4 style="color: #4B164C; margin: 15px 0 10px 0;">Available Support:</h4>
    <ul style="margin-left: 20px; margin-bottom: 15px;">
        <li><strong>Counseling:</strong> Professional support to help process your experience</li>
        <li><strong>Legal Aid:</strong> Information about your rights and legal options</li>
        <li><strong>Safe Accommodation:</strong> Temporary shelter if needed</li>
        <li><strong>Support Groups:</strong> Connect with others who understand</li>
    </ul>`;
    
    // Closing message
    response += `<p style="margin-top: 20px; padding: 15px; background: #e8f5e8; border-radius: 8px; color: #155724;">
        <strong>Remember:</strong> You are not alone, and what happened is not your fault. Take your time completing this report, and only share what feels safe for you. Your wellbeing is the priority.
    </p>`;
    
    response += `</div>`;
    
    return response;
}

function populateReview() {
    const incidentType = document.getElementById('incidentType');
    const urgency = document.getElementById('urgency');
    const timeframe = document.getElementById('timeframe');
    const location = document.getElementById('location').value;
    const description = document.getElementById('description').value;
    const needsSupport = document.getElementById('needsSupport').checked;
    
    document.getElementById('reviewIncidentType').textContent = 
        incidentType.options[incidentType.selectedIndex].text;
    document.getElementById('reviewUrgency').textContent = 
        urgency.options[urgency.selectedIndex].text;
    document.getElementById('reviewTimeframe').textContent = 
        timeframe.options[timeframe.selectedIndex].text;
    document.getElementById('reviewLocation').textContent = 
        location || 'Not specified';
    document.getElementById('reviewDescription').textContent = 
        description || 'Not provided';
    document.getElementById('reviewSupport').textContent = 
        needsSupport ? 'Yes' : 'No';
}

// Submit report
async function submitReport(event) {
    const submitBtn = event.target;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Submitting...';
    
    try {
        // Collect all form data
        const reportData = {
            incidentType: document.getElementById('incidentType').value,
            urgency: document.getElementById('urgency').value,
            timeframe: document.getElementById('timeframe').value,
            location: document.getElementById('location').value,
            description: document.getElementById('description').value,
            needsSupport: document.getElementById('needsSupport').checked,
            timestamp: new Date().toISOString()
        };
        
        // Submit to backend
        const response = await fetch('submit_anonymous_report.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(reportData)
        });
        
        if (response.ok) {
            const result = await response.json();
            
            // Show success message
            document.body.innerHTML = `
                <div style="min-height: 100vh; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #F8E7F6 0%, #E8D5E8 100%); padding: 20px;">
                    <div style="background: white; padding: 40px; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); text-align: center; max-width: 600px;">
                        <div style="font-size: 4rem; margin-bottom: 20px;">✅</div>
                        <h2 style="color: #4B164C; margin-bottom: 15px;">Report Submitted Successfully</h2>
                        <p style="color: #666; line-height: 1.6; margin-bottom: 20px;">
                            Thank you for submitting your anonymous report. Your information has been securely recorded and will be used to improve safety measures and support services.
                        </p>
                        <p style="color: #666; line-height: 1.6; margin-bottom: 30px;">
                            <strong>Report ID:</strong> ${result.reportId || 'Generated'}
                        </p>
                        <div style="background: #e8f5e8; padding: 20px; border-radius: 10px; margin-bottom: 30px;">
                            <h4 style="color: #155724; margin-bottom: 10px;">🔒 Your Privacy is Protected</h4>
                            <p style="color: #155724; margin: 0; font-size: 14px;">
                                No personal identifying information was collected or stored. This report is completely anonymous.
                            </p>
                        </div>
                        <div style="display: flex; gap: 15px; justify-content: center; flex-wrap: wrap;">
                            <a href="home.php" style="background: linear-gradient(135deg, #DD88CF, #4B164C); color: white; padding: 12px 25px; border-radius: 25px; text-decoration: none; font-weight: 600;">Return Home</a>
                            <a href="support.html" style="background: #f5f5f5; color: #666; padding: 12px 25px; border-radius: 25px; text-decoration: none; font-weight: 600; border: 2px solid #E0E0E0;">Get Support</a>
                        </div>
                    </div>
                </div>
            `;
        } else {
            throw new Error('Failed to submit report');
        }
        
    } catch (error) {
        console.error('Submit Error:', error);
        showError('Unable to submit report at this time. Please try again or contact support.');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Submit Anonymous Report';
    }
}

// Utility functions
function clearForm() {
    document.querySelectorAll('select, textarea, input[type="checkbox"]').forEach(field => {
        if (field.type === 'checkbox') {
            field.checked = false;
        } else {
            field.value = '';
        }
        field.style.borderColor = '#E0E0E0';
    });
    
    currentStep = 1;
    updateStepDisplay();
}

// Emergency contact functions
function callEmergency(number) {
    if (confirm(`Call ${number}?`)) {
        window.location.href = `tel:${number}`;
    }
}

// Export functions for global access
window.nextStep = nextStep;
window.previousStep = previousStep;
window.getAIGuidance = getAIGuidance;
window.submitReport = submitReport;
window.clearForm = clearForm;
