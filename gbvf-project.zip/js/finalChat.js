document.addEventListener('DOMContentLoaded', function() {
    // Cache DOM elements to avoid repeated lookups
    const chatMessages = document.getElementById('chatMessages');
    const messageInput = document.getElementById('messageInput');
    const sendButton = document.getElementById('sendMessage');
    const quickExitButton = document.getElementById('quickExit');
    const categoryButtons = document.querySelectorAll('.category');
    const closePanelButton = document.querySelector('.close-panel');
    const resourcePanel = document.querySelector('.resource-panel');
    const resourceLinks = document.querySelectorAll('.support-options a');
    const counselorStatus = document.querySelector('.counselor-status');
    const clearChatButton = document.querySelector('.clear-chat');
    const downloadChatButton = document.querySelector('.download-chat');
    const emojiButton = document.querySelector('.emoji-btn');
    const emojiPicker = document.getElementById('emojiPicker');
    const emergencyButton = document.getElementById('emergencyBtn');
    const chatWithCounselorLink = document.getElementById('chatWithCounselorLink');
    const counselorSelectionPanel = document.getElementById('counselorSelectionPanel');
    const chatInterface = document.getElementById('chatInterface');
    const counselorListDiv = counselorSelectionPanel.querySelector('.counselor-list');
    const currentCounselorNameSpan = document.getElementById('currentCounselorName');
    const anonymousAvatar = document.querySelector('.anonymous-avatar span');
    const userInfoName = document.querySelector('.user-info h3');
    // New: Cache the resource-content div
    const resourceContentDiv = document.querySelector('.resource-content');


    // --- API Configuration ---
    const phpApiUrl = 'http://localhost/website/GBVF_Project/api.php';
    const geminiApiKey = "AIzaSyAFAYp5fJWuXKU4sTTcs_Nu36EovnxaAJM";
    const geminiApiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${geminiApiKey}`;

    let selectedCounselor = null;
    const counselors = [
        { name: 'Zandi', bio: 'Specializes in emotional support and stress management.' },
        { name: 'Sipho', bio: 'Focuses on relationship issues and conflict resolution.' },
        { name: 'Lindiwe', bio: 'Expert in grief counseling and coping strategies.' },
        { name: 'Thabo', bio: 'Provides guidance on financial stress and career challenges.' },
        { name: 'Naledi', bio: 'Offers support for anxiety, depression, and self-esteem.' }
    ];

    // --- New: Resource Data Structure ---
    const resourceData = {
        'safety-planning': [
            {
                title: 'Creating a Personal Safety Plan',
                description: 'A safety plan helps you prepare for and react to dangerous situations. It includes identifying warning signs, developing coping strategies, and outlining emergency contacts and escape routes.',
                link: { text: 'Download Safety Plan Template', url: '#' } // Placeholder URL
            },
            {
                title: 'Emergency Contacts',
                description: 'Crucial numbers to keep readily available:',
                list: [
                    'Police: 10111',
                    'GBV Command Centre: 0800 428 428',
                    'Ambulance: 10177',
                    'National Crisis Line: 0800 150 150'
                ]
            },
            {
                title: 'Digital Safety Tips',
                description: 'Protect your online presence and data:',
                link: { text: 'Read More on Digital Security', url: '#' } // Placeholder URL
            }
        ],
        'legal': [
            {
                title: 'Understanding Your Rights',
                description: 'Information about your legal rights regarding domestic violence, protection orders, and child custody.',
                link: { text: 'Legal Aid South Africa', url: 'https://legal-aid.co.za/' }
            },
            {
                title: 'Applying for a Protection Order',
                description: 'Steps to follow when applying for a domestic violence protection order through the courts.',
                link: { text: 'Guide to Protection Orders', url: '#' } // Placeholder URL
            }
        ],
        'shelter': [
            {
                title: 'Finding Safe Shelters',
                description: 'A list of organizations and helplines that can assist in finding safe accommodation for survivors of gender-based violence.',
                list: [
                    'POWA (People Opposing Women Abuse): 011 642 4345',
                    'LifeLine Southern Africa: 0861 322 322',
                    'FAMSA (Families South Africa): Contact your local branch for shelter referrals.'
                ]
            },
            {
                title: 'Shelter Admission Process',
                description: 'Information on what to expect when seeking refuge in a shelter, including typical requirements and services provided.',
                link: { text: 'Understanding Shelter Services', url: '#' } // Placeholder URL
            }
        ],
        // Add more categories as needed
        'financial': [
            {
                title: 'Financial Independence',
                description: 'Guidance on budgeting, opening a bank account, and managing finances independently.',
                link: { text: 'Start Your Financial Journey', url: '#' }
            },
            {
                title: 'Accessing Financial Aid',
                description: 'Information on government grants and NGOs offering financial assistance to survivors.',
                link: { text: 'Explore Aid Programs', url: '#' }
            }
        ],
        'emotional': [
            {
                title: 'Coping with Trauma',
                description: 'Techniques and strategies to manage emotional distress, anxiety, and PTSD symptoms.',
                link: { text: 'Mindfulness Exercises', url: '#' }
            },
            {
                title: 'Seeking Counseling & Therapy',
                description: 'How to find professional psychological support and the benefits of therapy.',
                list: [
                    'Psychological Society of South Africa (PSYSSA): Find a Psychologist',
                    'South African Depression and Anxiety Group (SADAG): 0800 21 22 23'
                ]
            }
        ]
        // You can add more categories and their content here.
    };


    // --- User and Chat Session Management ---
    let currentChatSessionId = null;
    let currentUsername = null;

    // Reuse common dialog elements for better performance
    let usernameDialog = null;
    let alertDialog = null;
    let confirmDialog = null;

    // Helper to create or retrieve a dialog element
    function getOrCreateDialog(id, innerHTMLContent) {
        let dialog = document.getElementById(id);
        if (!dialog) {
            dialog = document.createElement('div');
            dialog.id = id;
            dialog.classList.add('custom-dialog-overlay');
            dialog.innerHTML = innerHTMLContent;
            document.body.appendChild(dialog);
        }
        return dialog;
    }

    function getOrCreateChatSessionId() {
        if (!currentChatSessionId && currentUsername) {
            currentChatSessionId = `session_${currentUsername}_${crypto.randomUUID()}`;
            localStorage.setItem('safeHavenChatSessionId', currentChatSessionId);
        }
        return currentChatSessionId;
    }

    function showUsernamePrompt() {
        if (!usernameDialog) {
            usernameDialog = getOrCreateDialog('customUsernameDialog', `
                <div class="custom-dialog-content">
                    <p>Please enter your username:</p>
                    <input type="text" id="usernameInput" placeholder="Your username">
                    <div class="custom-dialog-buttons">
                        <button id="usernameSubmitBtn">Submit</button>
                    </div>
                </div>
            `);
        }

        const usernameInput = document.getElementById('usernameInput');
        const submitBtn = document.getElementById('usernameSubmitBtn');

        usernameDialog.style.display = 'flex';
        usernameInput.value = localStorage.getItem('safeHavenUsername') || ''; // Pre-fill if exists

        // Use a single, clean event listener for the submit button
        submitBtn.onclick = () => { // Direct assignment is fine here as it's the only handler
            const username = usernameInput.value.trim();
            if (username) {
                currentUsername = username;
                localStorage.setItem('safeHavenUsername', username);
                usernameDialog.style.display = 'none';
                currentChatSessionId = null; // Reset to force new session for new username
                initializeChatSession();
            } else {
                showAlertDialog('Please enter a valid username.');
            }
        };
        usernameInput.focus();
    }

    function showAlertDialog(message) {
        if (!alertDialog) {
            alertDialog = getOrCreateDialog('customAlertDialog', `
                <div class="custom-dialog-content">
                    <p id="customAlertDialogMessage"></p>
                    <div class="custom-dialog-buttons">
                        <button id="customAlertDialogClose">OK</button>
                    </div>
                </div>
            `);
        }

        document.getElementById('customAlertDialogMessage').textContent = message;
        alertDialog.style.display = 'flex';

        const closeBtn = document.getElementById('customAlertDialogClose');
        closeBtn.onclick = () => { // Direct assignment is fine here
            alertDialog.style.display = 'none';
        };
    }

    // --- Helper Functions ---
    function scrollToBottom() {
        // Use requestAnimationFrame for smoother scrolling if many messages are added at once
        requestAnimationFrame(() => {
            chatMessages.scrollTop = chatMessages.scrollHeight;
        });
    }

    function escapeHTML(text) {
        // Using a temporary div is still a robust way to escape HTML
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Optimized message display functions to minimize DOM manipulations per message
    function createMessageElement(message, senderClass, timeString, isTyping = false) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', senderClass);
        if (isTyping) {
            messageDiv.classList.add('is-typing');
            messageDiv.innerHTML = `
                <div class="typing-indicator">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            `;
        } else {
            messageDiv.innerHTML = `
                <div class="message-content">
                    <p>${escapeHTML(message)}</p>
                </div>
                <div class="message-time">${timeString}</div>
            `;
        }
        return messageDiv;
    }

    function displayUserMessage(message, timestamp = new Date()) {
        const now = new Date(timestamp);
        const timeString = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
        const messageElement = createMessageElement(message, 'user', timeString);

        const typingIndicator = document.querySelector('.is-typing');
        if (typingIndicator) {
            // Insert before the typing indicator to maintain order
            chatMessages.insertBefore(messageElement, typingIndicator);
        } else {
            chatMessages.appendChild(messageElement);
        }
        scrollToBottom();
    }

    function displayCounselorMessage(message, timestamp = new Date()) {
        const now = new Date(timestamp);
        const timeString = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
        const messageElement = createMessageElement(message, 'counselor', timeString);
        chatMessages.appendChild(messageElement);
        scrollToBottom();
    }

    function showTypingIndicator() {
        hideTypingIndicator(); // Ensure only one typing indicator
        const typingElement = createMessageElement('', 'counselor', '', true);
        chatMessages.appendChild(typingElement);
        scrollToBottom();
        counselorStatus.textContent = selectedCounselor ? `${selectedCounselor.name} is typing...` : 'Counselor is typing...';
    }

    function hideTypingIndicator() {
        const typingIndicator = document.querySelector('.is-typing');
        if (typingIndicator) {
            typingIndicator.remove();
        }
        counselorStatus.textContent = 'Online';
    }

    // --- Database Interaction Functions ---
    async function saveMessageToDatabase(sender, message, counselorName) {
        const chatSessionId = getOrCreateChatSessionId();
        if (!chatSessionId) {
            console.error("Cannot save message: No chat session ID available.");
            return;
        }

        try {
            const response = await fetch(phpApiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    chatSessionId: chatSessionId,
                    sender: sender,
                    messageContent: message,
                    counselorName: counselorName,
                    username: currentUsername
                })
            });

            if (!response.ok) {
                const errorData = await response.json();
                console.error("Backend Save Error Status:", response.status, "Data:", errorData);
                throw new Error(`Failed to save message: ${errorData.message || response.statusText}`);
            }
        } catch (error) {
            console.error('Error saving message to database:', error);
        }
    }

    async function loadChatHistory(session_id) {
        if (!session_id || !currentUsername) {
            console.warn("Cannot load chat history: Session ID or Username not available.");
            return;
        }

        try {
            const response = await fetch(`${phpApiUrl}?session_id=${session_id}&username=${currentUsername}`);
            if (!response.ok) {
                const errorData = await response.json();
                console.error("Backend Load Error Status:", response.status, "Data:", errorData);
                throw new Error(`Failed to load chat history: ${errorData.message || response.statusText}`);
            }
            const data = await response.json();

            if (data.status === 'success' && data.messages) {
                // Use a DocumentFragment for batch DOM updates
                const fragment = document.createDocumentFragment();
                chatMessages.innerHTML = ''; // Clear existing messages
                const now = new Date();
                const timeString = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

                const historyHeader = document.createElement('div');
                historyHeader.classList.add('message-timestamp');
                historyHeader.innerHTML = `<span>Chat History Loaded for ${currentUsername}</span>`;
                fragment.appendChild(historyHeader);

                data.messages.forEach(msg => {
                    if (msg.sender === 'user') {
                        fragment.appendChild(createMessageElement(msg.message_content, 'user', `${new Date(msg.timestamp).getHours().toString().padStart(2, '0')}:${new Date(msg.timestamp).getMinutes().toString().padStart(2, '0')}`));
                    } else {
                        fragment.appendChild(createMessageElement(msg.message_content, 'counselor', `${new Date(msg.timestamp).getHours().toString().padStart(2, '0')}:${new Date(msg.timestamp).getMinutes().toString().padStart(2, '0')}`));
                    }
                });
                chatMessages.appendChild(fragment); // Append once
                scrollToBottom();
            } else {
                console.error('Error loading chat history from PHP:', data.message);
            }
        } catch (error) {
            console.error('Error loading chat history:', error);
        }
    }

    // --- Main Chat Logic (Optimized) ---
    async function sendMessage() {
        const message = messageInput.value.trim();
        if (!message) return;

        // Immediately display user message and clear input for responsiveness
        displayUserMessage(message);
        messageInput.value = '';
        sendButton.disabled = true; // Disable button immediately

        showTypingIndicator();

        try {
            const chatHistory = [{ role: "user", parts: [{ text: message }] }];

            const generationConfig = {
                maxOutputTokens: 100,
                temperature: 0.7,
                topP: 0.95,
            };

            const systemInstruction = {
                parts: [{
                    text: `You are ${selectedCounselor.name}, a supportive and empathetic counselor for Safe Haven. Your goal is to provide concise, helpful, and reassuring responses. Focus on active listening, validating feelings, and offering practical, brief guidance or asking open-ended questions to encourage further sharing. Keep your responses under 100 words. Remember your specialty is: ${selectedCounselor.bio}`
                }]
            };

            const payload = {
                contents: chatHistory,
                generationConfig: generationConfig,
                systemInstruction: systemInstruction
            };

            const response = await fetch(geminiApiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                const errorData = await response.json();
                console.error("Gemini API Response Error Status:", response.status, "Data:", errorData);
                throw new Error(`Gemini API error: ${response.status} - ${errorData.error.message || 'Unknown API error'}`);
            }

            const result = await response.json();
            let botResponse = "Sorry, I couldn't get a clear response from the AI. Please try again.";

            if (result.candidates && result.candidates.length > 0 &&
                result.candidates[0].content && result.candidates[0].content.parts &&
                result.candidates[0].content.parts.length > 0) {
                botResponse = result.candidates[0].content.parts[0].text;
            } else {
                console.error("Unexpected Gemini API response structure:", result);
            }

            displayCounselorMessage(botResponse);
            await saveMessageToDatabase('counselor', botResponse, selectedCounselor.name);
        } catch (error) {
            console.error("Error sending message to Gemini API or saving to DB:", error);
            displayCounselorMessage("Oops! Something went wrong while processing your message. Please try again.");
        } finally {
            hideTypingIndicator();
            sendButton.disabled = false;
            messageInput.focus();
        }
    }

    // Event listener for send button (already good)
    sendButton.addEventListener('click', sendMessage);

    // Optimized keypress listener using a more robust debounce
    let sendMessageDebounceTimer;
    messageInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    function renderCounselorList() {
        const fragment = document.createDocumentFragment();
        counselors.forEach(counselor => {
            const counselorCard = document.createElement('div');
            counselorCard.classList.add('counselor-card');
            counselorCard.innerHTML = `
                <div class="counselor-avatar">${counselor.name.charAt(0)}</div>
                <h4>${counselor.name}</h4>
                <p>${counselor.bio}</p>
            `;
            counselorCard.addEventListener('click', () => startChatSession(counselor));
            fragment.appendChild(counselorCard);
        });
        counselorListDiv.innerHTML = '';
        counselorListDiv.appendChild(fragment);
    }

    async function startChatSession(counselor) {
        selectedCounselor = counselor;
        currentCounselorNameSpan.textContent = counselor.name;
        counselorStatus.textContent = 'Online';

        // Use display 'none' / 'flex' for faster hiding/showing than manipulating child elements
        counselorSelectionPanel.style.display = 'none';
        chatInterface.style.display = 'flex';

        const sessionId = getOrCreateChatSessionId();
        if (!sessionId) {
            console.error("Session ID not available to start chat session.");
            return;
        }

        await loadChatHistory(sessionId);

        if (chatMessages.children.length <= 1) { // Checks if only the timestamp is present
            const initialMessage = `Hello and welcome to Safe Haven, ${currentUsername}. My name is ${counselor.name} and I'm here to support you. Everything you share is confidential. How can I help you today?`;
            displayCounselorMessage(initialMessage);
            await saveMessageToDatabase(counselor.name, initialMessage, counselor.name);
        }

        scrollToBottom();
        messageInput.focus();
    }

    // Event listeners for quick exit and emergency button
    if (emergencyButton) {
        emergencyButton.addEventListener('click', () => window.location.href = 'https://www.google.com');
    }

    quickExitButton.addEventListener('click', () => window.location.href = 'https://www.google.com');

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            window.location.href = 'https://www.google.com';
        }
    });

    if (clearChatButton) {
        clearChatButton.addEventListener('click', () => {
            showConfirmationDialog("Are you sure you want to clear the entire chat history? This action cannot be undone.", async function() {
                localStorage.removeItem('safeHavenChatSessionId');
                currentChatSessionId = null;
                chatMessages.innerHTML = '';

                if (selectedCounselor) {
                    await startChatSession(selectedCounselor);
                } else {
                    const now = new Date();
                    const timeString = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
                    chatMessages.innerHTML = `
                        <div class="message-timestamp">
                            <span>Today, ${timeString}</span>
                        </div>
                        <div class="message counselor">
                            <div class="message-content">
                                <p>Hello and welcome to Safe Haven. How can I help you today?</p>
                            </div>
                            <div class="message-time">${timeString}</div>
                        </div>
                    `;
                    saveMessageToDatabase('Counselor', 'Hello and welcome to Safe Haven. How can I help you today?', 'N/A');
                    scrollToBottom();
                }
                console.log('Chat history cleared and session ID reset.');
            }, () => {
                console.log('Chat clear cancelled.');
            });
        });
    }

    function showConfirmationDialog(message, onConfirm, onCancel) {
        if (!confirmDialog) {
            confirmDialog = getOrCreateDialog('customConfirmDialog', `
                <div class="custom-dialog-content">
                    <p id="customDialogMessage"></p>
                    <div class="custom-dialog-buttons">
                        <button id="customDialogConfirm">Confirm</button>
                        <button id="customDialogCancel">Cancel</button>
                    </div>
                </div>
            `);
        }

        document.getElementById('customDialogMessage').textContent = message;
        confirmDialog.style.display = 'flex';

        const confirmBtn = document.getElementById('customDialogConfirm');
        const cancelBtn = document.getElementById('customDialogCancel');

        confirmBtn.onclick = () => { confirmDialog.style.display = 'none'; if (onConfirm) onConfirm(); };
        cancelBtn.onclick = () => { confirmDialog.style.display = 'none'; if (onCancel) onCancel(); };
    }

    if (downloadChatButton) {
        downloadChatButton.addEventListener('click', () => {
            let chatTranscript = '';
            const messages = chatMessages.children;

            for (const item of messages) {
                if (item.classList.contains('message-timestamp')) {
                    chatTranscript += `--- ${item.querySelector('span').textContent} ---\n`;
                } else if (item.classList.contains('message')) {
                    const sender = item.classList.contains('user') ? 'User' : (selectedCounselor ? selectedCounselor.name : 'Counselor');
                    const content = item.querySelector('.message-content p').textContent;
                    const time = item.querySelector('.message-time') ? item.querySelector('.message-time').textContent : '';
                    chatTranscript += `${sender} (${time}): ${content}\n`;
                }
            }

            const blob = new Blob([chatTranscript], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);

            const a = document.createElement('a');
            a.href = url;
            a.download = `chat_transcript_${selectedCounselor ? selectedCounselor.name.toLowerCase() : 'general'}_${new Date().toISOString().slice(0,10)}.txt`;
            document.body.appendChild(a);
            a.click();

            document.body.removeChild(a);
            URL.revokeObjectURL(url);

            displayCounselorMessage("Your chat transcript has been downloaded!");
            console.log('Chat transcript downloaded.');
        });
    }

    const emojis = ['😀', '😃', '😄', '😁', '😅', '😂', '🥲', '😊', '😇', '🙂', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚', '😋', '😛', '😜', '🤪', '😝', '🤗', '🤔', '🤫', '😶', '😐', '😏', '😒', '🙄', '😬', '😮‍💨', '🤥', '😔', '😪', '🤤', '😴', '😷', '🤒', '🤕', '🤢', '🤮', '🤧', '🥵', '🥶', '😵', '🤯', '🤠', '🥳', '😎', '🤓', '🧐', '😕', '😟', '🙁', '☹️', '😮', '😯', '😳', '🥺', '😢', '😭', '😤', '😠', '😡', '🤬', '😈', '👿', '💀', '👻', '👽', '🤖', '💩', '🤝', '👍', '👎', '👏', '🙏', '❤️', '💔', '💖', '✨', '🔥', '🎉', '🌸', '🌷', '☀️', '🌈', '🫂'];

    if (emojiPicker) {
        // Use a DocumentFragment for efficient emoji rendering
        const emojiFragment = document.createDocumentFragment();
        emojis.forEach(emoji => {
            const span = document.createElement('span');
            span.textContent = emoji;
            span.addEventListener('click', () => {
                messageInput.value += emoji;
                messageInput.focus();
                emojiPicker.classList.remove('active');
            });
            emojiFragment.appendChild(span);
        });
        emojiPicker.appendChild(emojiFragment);
    }

    if (emojiButton) {
        emojiButton.addEventListener('click', function(event) {
            event.stopPropagation();
            emojiPicker.classList.toggle('active');
        });
    }

    // Efficiently close emoji picker when clicking outside
    document.addEventListener('click', function(event) {
        if (emojiPicker && !emojiPicker.contains(event.target) && emojiButton && !emojiButton.contains(event.target)) {
            emojiPicker.classList.remove('active');
        }
    });

    // --- New: Function to render resource content ---
    function renderResourceContent(category) {
        const data = resourceData[category];
        if (!data) {
            resourceContentDiv.innerHTML = '<p>No resources found for this category.</p>';
            return;
        }

        const fragment = document.createDocumentFragment();

        data.forEach(item => {
            const resourceItemDiv = document.createElement('div');
            resourceItemDiv.classList.add('resource-item');

            const title = document.createElement('h4');
            title.textContent = item.title;
            resourceItemDiv.appendChild(title);

            const description = document.createElement('p');
            description.textContent = item.description;
            resourceItemDiv.appendChild(description);

            if (item.list) {
                const ul = document.createElement('ul');
                ul.classList.add('resource-list');
                item.list.forEach(listItem => {
                    const li = document.createElement('li');
                    li.textContent = listItem;
                    ul.appendChild(li);
                });
                resourceItemDiv.appendChild(ul);
            }

            if (item.link) {
                const link = document.createElement('a');
                link.href = item.link.url;
                link.classList.add('resource-link');
                link.textContent = item.link.text;
                link.target = '_blank'; // Open in new tab
                resourceItemDiv.appendChild(link);
            }
            fragment.appendChild(resourceItemDiv);
        });

        resourceContentDiv.innerHTML = '';
        resourceContentDiv.appendChild(fragment);
    }


    // Update the category button event listeners
    categoryButtons.forEach(button => {
        button.addEventListener('click', function() {
            categoryButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            const category = this.dataset.category;
            renderResourceContent(category);
            displayCounselorMessage(`Here are some helpful resources related to "${this.textContent}".`);
        });
    });

    // Set initial active category and display its resources
    const initialCategoryButton = document.querySelector('.category.active');
    if (initialCategoryButton) {
        renderResourceContent(initialCategoryButton.dataset.category);
    } else if (categoryButtons.length > 0) {
        categoryButtons[0].classList.add('active');
        renderResourceContent(categoryButtons[0].dataset.category);
    }


    if (closePanelButton) {
        closePanelButton.addEventListener('click', function() {
            if (resourcePanel) {
                resourcePanel.style.display = 'none';
            }
        });
    }

    resourceLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            resourceLinks.forEach(lnk => lnk.classList.remove('active'));
            this.classList.add('active');
            const option = this.className.split(' ')[0];
            console.log(`Switched to ${option}. Changing chat context.`);
            if (option === 'counselor-chat') {
                showCounselorSelection();
            } else {
                displayCounselorMessage(`You've selected "${this.textContent}". The chat context would change here.`);
            }
        });
    });

    function showCounselorSelection() {
        chatInterface.style.display = 'none';
        counselorSelectionPanel.style.display = 'flex';
        renderCounselorList();
    }

    // Debounce resize events for adjustLayout
    let resizeTimer;
    function adjustLayout() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
            if (window.innerWidth <= 992 && window.innerWidth > 768) {
                if (resourcePanel) resourcePanel.style.display = 'none';
            } else if (window.innerWidth > 992) {
                if (resourcePanel) resourcePanel.style.display = 'flex';
            }
        }, 200);
    }

    window.addEventListener('resize', adjustLayout);
    adjustLayout(); // Initial call

    async function initializeChatSession() {
        if (currentUsername) {
            anonymousAvatar.textContent = currentUsername.charAt(0).toUpperCase();
            userInfoName.textContent = currentUsername;
        }

        const sessionId = getOrCreateChatSessionId();
        if (sessionId) {
            await loadChatHistory(sessionId);
            showCounselorSelection();
        } else {
            console.error("Failed to get session ID after username entry.");
        }
    }

    showUsernamePrompt();
});

// Add basic CSS for the custom dialogs (username prompt, confirm, alert)
const style = document.createElement('style');
style.textContent = `
    .custom-dialog-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.6);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 1000;
        display: none; /* Hidden by default */
    }

    .custom-dialog-content {
        background-color: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        text-align: center;
        max-width: 400px;
        width: 90%;
        font-family: 'Inter', sans-serif;
    }

    .custom-dialog-content p {
        margin-bottom: 20px;
        font-size: 1.1em;
        color: #333;
    }

    .custom-dialog-content input[type="text"] {
        width: calc(100% - 20px);
        padding: 10px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 1em;
    }

    .custom-dialog-buttons button {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 1em;
        margin: 0 10px;
        transition: background-color 0.3s ease;
    }

    .custom-dialog-buttons button:hover {
        background-color: #45a049;
    }

    .custom-dialog-buttons #customDialogCancel,
    .custom-dialog-buttons #customAlertDialogClose {
        background-color: #f44336;
    }

    .custom-dialog-buttons #customDialogCancel:hover,
    .custom-dialog-buttons #customAlertDialogClose:hover {
        background-color: #da190b;
    }
`;
document.head.appendChild(style);

document.addEventListener('DOMContentLoaded', function() {

    const currentPath = window.location.pathname;
    const currentPageFilename = currentPath.split('/').pop();

    const mainNavLinks = document.querySelectorAll('.main-nav-sticky ul li a');

    mainNavLinks.forEach(link => {

    const linkFilename = link.getAttribute('href').split('/').pop();

        link.classList.remove('active', 'active-page');
        link.removeAttribute('aria-current');

            if (linkFilename === currentPageFilename) {
                link.classList.add('active-page');
                link.setAttribute('aria-current', 'page');
            }
      });
});
