<?php
include 'Database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $surname = trim($_POST['surname']);
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $password = trim($_POST['password']);

    $errors = [];

    if (empty($name) || !preg_match("/^[a-zA-Z-' ]*$/", $name)) {
        $errors[] = "Invalid name.";
        header('Location: InitialPage.php');
    }
    if (empty($surname) || !preg_match("/^[a-zA-Z-' ]*$/", $surname)) {
        $errors[] = "Invalid surname.";
        header('Location: InitialPage.php');
    }
    if (empty($username)) {
        $errors[] = "Username is required.";
        header('Location: InitialPage.php');
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
        header('Location: InitialPage.php');
    }
    if (!preg_match("/^[0-9]{10,13}$/", $phone)) {
        $errors[] = "Phone number must be 10 to 13 digits.";
         header('Location: InitialPage.php');
    }
    if (empty($address)) {
        $errors[] = "Address is required.";
         header('Location: InitialPage.php');
    }
    if (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters long.";
        header('Location: InitialPage.php');
    }

    if (count($errors) > 0) {
        foreach ($errors as $error) {
            echo "<p style='color:red;'>$error</p>";
            header('Location: InitialPage.php');
        }
        exit();
    }

    $stmt = $conn->prepare("INSERT INTO users (name, surname, username, email, phone, address, password) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $name, $surname, $username, $email, $phone, $address, $password);

    if ($stmt->execute()) {
        echo "New record created successfully";
        header('Location: InitialPage.php');
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<!-- HTML Form -->
<form method="POST" action="">
    <input type="text" name="name" placeholder="Name" required pattern="[A-Za-z\s]+" /><br>
    <input type="text" name="surname" placeholder="Surname" required pattern="[A-Za-z\s]+" /><br>
    <input type="text" name="username" placeholder="Username" required /><br>
    <input type="email" name="email" placeholder="Email" required /><br>
    <input type="tel" name="phone" placeholder="Phone" required pattern="\d{10,13}" /><br>
    <input type="text" name="address" placeholder="Address" required /><br>
    <input type="password" name="password" placeholder="Password" required minlength="8" /><br>
    <button type="submit">Submit</button>
</form>
