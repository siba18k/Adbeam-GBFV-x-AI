<?php
include 'Database.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    $stmt = $conn->prepare("DELETE FROM emergency_contacts WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header('Location: InitialPage.php');
        exit;
    } else {
        echo "Error deleting emergency contact: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Invalid request. Contact ID missing.";
}

$conn->close();
?>
