<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link href="Styling.css" rel="stylesheet">
</head>
<body>

<?php
include 'Database.php';

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];

    
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "User not found.";
        exit;
    }

    $stmt->close();
} else {
    echo "Invalid ID.";
    exit;
}

function escape($value) {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}
?>

<form action="Update.php" method="POST">
    <input type="hidden" name="id" value="<?php echo escape($row['id']); ?>">
    <label>NAME:</label>
    <input type="text" name="name" value="<?php echo escape($row['name']); ?>" required><br><br>
    <label>SURNAME:</label>
    <input type="text" name="surname" value="<?php echo escape($row['surname']); ?>" required><br><br>
    <label>USERNAME:</label>
    <input type="text" name="username" value="<?php echo escape($row['username']); ?>" required><br><br>
    <label>EMAIL:</label>
    <input type="email" name="email" value="<?php echo escape($row['email']); ?>" required><br><br>
    <label>PHONE:</label>
    <input type="text" name="phone" value="<?php echo escape($row['phone']); ?>" required><br><br>
    <label>ADDRESS:</label>
    <input type="text" name="address" value="<?php echo escape($row['address']); ?>" required><br><br>
    <label>PASSWORD:</label>
    <input type="text" name="password" value="<?php echo escape($row['password']); ?>" required><br><br>

    <button type="submit">UPDATE USER</button>
</form>

</body>
</html>
