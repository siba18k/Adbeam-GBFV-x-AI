<?php
include 'Database.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Cast to int to prevent injection

    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header('Location: InitialPage.php');
        exit;
    } else {
        echo "Error deleting user: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Invalid request. User ID missing.";
}

$conn->close();
?>
