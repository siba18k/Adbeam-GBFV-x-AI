<?php
session_start();


$config = require 'C:/xampp/secure_config/config.php';

$host = $config['host'];
$db   = $config['db'];
$user = $config['user'];
$pass = $config['pass'];

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = "";
$success = false;


if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $conn->query("DELETE FROM emergency_contacts WHERE user_id = $delete_id");
    $conn->query("DELETE FROM users WHERE id = $delete_id");
    header("Location: registration.php");
    exit;
}


$edit_user = null;
if (isset($_GET['edit_id'])) {
    $edit_id = intval($_GET['edit_id']);
    $result = $conn->query("SELECT * FROM users WHERE id = $edit_id");
    $edit_user = $result->fetch_assoc();
}


if (isset($_POST['update_id'])) {
    $update_id = intval($_POST['update_id']);
    $username = $conn->real_escape_string($_POST["username"]);
    $name = $conn->real_escape_string($_POST["name"]);
    $surname = $conn->real_escape_string($_POST["surname"]);
    $email = $conn->real_escape_string($_POST["email"]);
    $phone = $conn->real_escape_string($_POST["phone"]);
    $address = $conn->real_escape_string($_POST["address"]);

    $conn->query("UPDATE users SET username='$username', name='$name', surname='$surname', email='$email', phone='$phone', address='$address' WHERE id=$update_id");

    $conn->query("DELETE FROM emergency_contacts WHERE user_id = $update_id");
    if (isset($_POST["contact_name"])) {
        $stmt = $conn->prepare("INSERT INTO emergency_contacts (user_id, contact_name, contact_phone, relationship) VALUES (?, ?, ?, ?)");
        for ($i = 0; $i < count($_POST["contact_name"]); $i++) {
            $contact_name = $conn->real_escape_string($_POST["contact_name"][$i]);
            $contact_phone = $conn->real_escape_string($_POST["contact_phone"][$i]);
            $relationship = $conn->real_escape_string($_POST["relationship"][$i]);
            if (!empty($contact_name) && !empty($contact_phone)) {
                $stmt->bind_param("isss", $update_id, $contact_name, $contact_phone, $relationship);
                $stmt->execute();
            }
        }
        $stmt->close();
    }

    header("Location: registration.php");
    exit;
}


if ($_SERVER["REQUEST_METHOD"] == "POST" && !isset($_POST['update_id'])) {
    $username = $conn->real_escape_string($_POST["username"]);
    $name = $conn->real_escape_string($_POST["name"]);
    $surname = $conn->real_escape_string($_POST["surname"]);
    $email = $conn->real_escape_string($_POST["email"]);
    $phone = $conn->real_escape_string($_POST["phone"]);
    $address = $conn->real_escape_string($_POST["address"]);
    $password = $_POST["password"];
    $confirm_password = $_POST["confirm_password"];

    if ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $check = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $check->bind_param("s", $username);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $error = "Username already taken.";
        } else {
            $stmt = $conn->prepare("INSERT INTO users (username, name, surname, email, phone, address, password) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssssss", $username, $name, $surname, $email, $phone, $address, $hashed_password);
            $stmt->execute();
            $user_id = $stmt->insert_id;
            $stmt->close();

            if (isset($_POST["contact_name"])) {
                $stmt = $conn->prepare("INSERT INTO emergency_contacts (user_id, contact_name, contact_phone, relationship) VALUES (?, ?, ?, ?)");
                for ($i = 0; $i < count($_POST["contact_name"]); $i++) {
                    $contact_name = $conn->real_escape_string($_POST["contact_name"][$i]);
                    $contact_phone = $conn->real_escape_string($_POST["contact_phone"][$i]);
                    $relationship = $conn->real_escape_string($_POST["relationship"][$i]);
                    if (!empty($contact_name) && !empty($contact_phone)) {
                        $stmt->bind_param("isss", $user_id, $contact_name, $contact_phone, $relationship);
                        $stmt->execute();
                    }
                }
                $stmt->close();
            }

            $success = true;
        }
        $check->close();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" href="css/register_style.css">
</head>
<body>
    <form method="POST">
        <h2><?php echo $edit_user ? "Edit User" : "Register"; ?></h2>

        <?php if ($error): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php elseif ($success): ?>
            <p class="success">Registration successful!</p>
            <a href="login.php" class="success-btn">Go to Login</a>
        <?php endif; ?>

        <?php if ($edit_user): ?>
            <input type="hidden" name="update_id" value="<?php echo $edit_user['id']; ?>">
        <?php endif; ?>

        <div class="flex-column">
            <label>First Name</label>
            <div class="inputForm"><input type="text" name="name" required value="<?php echo $edit_user['name'] ?? ''; ?>"></div>
        </div>

        <div class="flex-column">
            <label>Last Name</label>
            <div class="inputForm"><input type="text" name="surname" required value="<?php echo $edit_user['surname'] ?? ''; ?>"></div>
        </div>

        <div class="flex-column">
            <label>Username</label>
            <div class="inputForm"><input type="text" name="username" required value="<?php echo $edit_user['username'] ?? ''; ?>"></div>
        </div>

        <div class="flex-column">
            <label>Email</label>
            <div class="inputForm"><input type="email" name="email" required value="<?php echo $edit_user['email'] ?? ''; ?>"></div>
        </div>

        <div class="flex-column">
            <label>Phone</label>
            <div class="inputForm"><input type="tel" name="phone" required value="<?php echo $edit_user['phone'] ?? ''; ?>"></div>
        </div>

        <div class="flex-column">
            <label>Address</label>
            <div class="inputForm"><input type="text" name="address" required value="<?php echo $edit_user['address'] ?? ''; ?>"></div>
        </div>

        <?php if (!$edit_user): ?>
        <div class="flex-column">
            <label>Password</label>
            <div class="inputForm password-wrapper">
                <input type="password" name="password" id="password" required>
                <label class="container">
                    <input type="checkbox" onclick="togglePassword('password')">
                    <div class="checkmark"></div>
                </label>
            </div>
        </div>

        <div class="flex-column">
            <label>Confirm Password</label>
            <div class="inputForm password-wrapper">
                <input type="password" name="confirm_password" id="confirm_password" required>
                <label class="container">
                    <input type="checkbox" onclick="togglePassword('confirm_password')">
                    <div class="checkmark"></div>
                </label>
            </div>
        </div>
        <?php endif; ?>

        <h3>Emergency Contacts (Up to 3)</h3>
        <div id="emergencyContacts">
            <?php
            if ($edit_user) {
                $result = $conn->query("SELECT * FROM emergency_contacts WHERE user_id = " . $edit_user['id']);
                while ($row = $result->fetch_assoc()) {
                    echo '
                    <div class="emergency-contact">
                        <div class="flex-column">
                            <label>Contact Name</label>
                            <div class="inputForm"><input type="text" name="contact_name[]" value="' . htmlspecialchars($row['contact_name']) . '"></div>
                        </div>
                        <div class="flex-column">
                            <label>Relationship</label>
                            <div class="inputForm"><input type="text" name="relationship[]" value="' . htmlspecialchars($row['relationship']) . '"></div>
                        </div>
                        <div class="flex-column">
                            <label>Contact Phone</label>
                            <div class="inputForm"><input type="tel" name="contact_phone[]" value="' . htmlspecialchars($row['contact_phone']) . '"></div>
                        </div>
                    </div>';
                }
            } else {
                echo '
                <div class="emergency-contact">
                    <div class="flex-column">
                        <label>Contact Name</label>
                        <div class="inputForm"><input type="text" name="contact_name[]"></div>
                    </div>
                    <div class="flex-column">
                        <label>Relationship</label>
                        <div class="inputForm"><input type="text" name="relationship[]"></div>
                    </div>
                    <div class="flex-column">
                        <label>Contact Phone</label>
                        <div class="inputForm"><input type="tel" name="contact_phone[]"></div>
                    </div>
                </div>';
            }
            ?>
        </div>

        <?php if (!$edit_user): ?>
            <button type="button" onclick="addContact()">+ Add Another Contact</button><br><br>
        <?php endif; ?>

        <button type="submit"><?php echo $edit_user ? "Update" : "Register"; ?></button>
    </form>


    <script>
    function addContact() {
        const container = document.getElementById('emergencyContacts');
        const count = container.querySelectorAll('.emergency-contact').length;
        if (count >= 3) return;

        const contactHTML = `
            <div class="emergency-contact">
                <div class="flex-column">
                    <label>Contact Name</label>
                    <div class="inputForm"><input type="text" name="contact_name[]"></div>
                </div>
                <div class="flex-column">
                    <label>Relationship</label>
                    <div class="inputForm"><input type="text" name="relationship[]"></div>
                </div>
                <div class="flex-column">
                    <label>Contact Phone</label>
                    <div class="inputForm"><input type="tel" name="contact_phone[]"></div>
                </div>
            </div>`;
        container.insertAdjacentHTML('beforeend', contactHTML);
    }

    function togglePassword(fieldId) {
        const field = document.getElementById(fieldId);
        field.type = field.type === "password" ? "text" : "password";
    }
    </script>
</body>
</html>
